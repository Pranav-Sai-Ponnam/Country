# Name:  
# Course number:  
# Lab title: 

def display_menu():
    print("1. View a Country")
    print("2. Add a Country")
    print("3. Delete a Country")
    print("4. Exit")

def prepopulate_countries():
    return {
        'KEN': 'Kenya',
        'USA': 'United States of America',
        'IND': 'India'
    }

def view_country(countries):
    print("Available countries:")
    for code in countries:
        print(code)
    key = input("Enter country code: ")
    if key in countries:
        print(f"{key}: {countries[key]}")
    else:
        print("Invalid country code")

def add_country(countries):
    key = input("Enter new country code: ")
    if key in countries:
        print("Country code already exists!")
    else:
        name = input("Enter country name: ")
        countries[key] = name
        print(f"Added {key}: {name}")

def delete_country(countries):
    key = input("Enter country code to delete: ")
    if key in countries:
        del countries[key]
        print(f"Deleted country {key}")
    else:
        print("Invalid country code")

def main():
    countries = prepopulate_countries()
    while True:
        display_menu()
        choice = input("Choose an option: ")
        if choice == '1':
            view_country(countries)
        elif choice == '2':
            add_country(countries)
        elif choice == '3':
            delete_country(countries)
        elif choice == '4':
            print("Exiting...")
            break
        else:
            print("Invalid choice, please try again.")

if __name__ == "__main__":
    main()

